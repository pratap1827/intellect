package user.service;

import user.bean.UserDetails;

public interface IUserService {

	UserDetails createUser(UserDetails userBean);

	UserDetails updateUser(UserDetails userBean);

	String deleteUser(String id);

}
