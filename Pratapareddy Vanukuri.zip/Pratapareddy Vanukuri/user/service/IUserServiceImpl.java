package user.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import user.CustomException;
import user.bean.UserDetails;

public class IUserServiceImpl implements IUserService {

	private static List<UserDetails> userList = new ArrayList<UserDetails>();
	private static Integer uniqueUserId = 0;

	@Override
	public UserDetails createUser(UserDetails userBean) {
		if (isNotNull(userBean)) {
			validateUser(userBean);
			uniqueUserId++;
			userBean.setId(uniqueUserId.toString());
			userList.add(userBean);
			return userBean;
		} else {
			return null;
		}

	}

	private void validateUser(UserDetails userBean) {
		if (isNotNull(userBean)) {

			/* Id validation */
			if (isNotNull(userBean.getEmial())) {
				validationForUniqueEmial(userBean.getEmial());
			} else {
				new CustomException("Email should not be null");
			}
			/* date validation */
			if (isNotNull(userBean.getBirthDate())) {
				dateValidation(userBean.getBirthDate());
			} else {
				new CustomException("Birth date should not be null");
			}

			/* Null validations */

			if (!isNotNull(userBean.getfName())) {
				new CustomException("Firt name should not be null");
			}
			if (!isNotNull(userBean.getlName())) {
				new CustomException("Last name should not be null");
			}
			if (!isNotNull(userBean.getPinCode())) {
				new CustomException("Pincode should not be null");
			}

		}
	}

	private void validationForUniqueEmial(String emial) {
		for (UserDetails userData : userList) {
			if (isNotNull(userData)) {
				if (userData.isActive() && userData.getEmial().equals(emial)) {
					new CustomException("Your email is already exits please select new id");
				}
			}
		}
	}

	private void dateValidation(Date birthDate) {

		boolean datevalid = isValidDate(birthDate.toString());
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
		Date currentDate = new Date();
		try {
			currentDate = format.parse(format.format(new Date()));
		} catch (ParseException e) {
			new CustomException("You have enterted invalid date");
		}
		if (datevalid) {
			if (birthDate.after(currentDate)) {
				new CustomException("You have enterted future date, please enter valid one");
			}
		} else {
			new CustomException("Please enter bithdate in proper format");
		}
	}

	boolean isValidDate(String input) {
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
		try {
			format.parse(input);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	/*
	 * private void validationForUniqueId(String id) { for (UserDetails userData
	 * : userList) { if (isNotNull(userData)) { if (userData.isActive() &&
	 * userData.getId().equals(id)) { new
	 * CustomException("Your id is already exits please select new id"); } } } }
	 */

	private boolean isNotNull(Object ob) {
		if (ob != null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public UserDetails updateUser(UserDetails userBean) {
		if (isNotNull(userBean)) {
			UserDetails existingUserBean = null;
			for (UserDetails userData : userList) {
				if (isNotNull(userData)) {
					if (userData.isActive() && userData.getId().equals(userBean.getId())) {
						existingUserBean = userData;
					}
				}
			}
			if (isNotNull(existingUserBean)) {
				userList.remove(existingUserBean);
				if (!isNotNull(userBean.getBirthDate())) {
					validatationForUpdate(userBean);
					existingUserBean.setBirthDate(userBean.getBirthDate());
				}
				if (!isNotNull(userBean.getPinCode())) {
					existingUserBean.setPinCode(userBean.getPinCode());
				}
				userList.add(existingUserBean);
				return existingUserBean;
			} else {
				new CustomException("User is not valid or active, we can't update");
				return null;
			}

		} else {
			return null;
		}
	}

	private void validatationForUpdate(UserDetails userBean) {

		/* date validation */
		if (isNotNull(userBean.getBirthDate())) {
			dateValidation(userBean.getBirthDate());
		} else {
			new CustomException("Birth date should not be null");
		}

	}

	@Override
	public String deleteUser(String id) {
		if (isNotNull(id)) {
			UserDetails existingUserBean = null;
			for (UserDetails userData : userList) {
				if (isNotNull(userData)) {
					if (userData.isActive() && userData.getId().equals(id)) {
						existingUserBean = userData;
					}
				}
			}
			if (isNotNull(existingUserBean)) {
				userList.remove(existingUserBean);
				existingUserBean.setActive(false);
				userList.add(existingUserBean);
				return existingUserBean.getId();
			} else {
				new CustomException("User is not valid or active, we can't delete");
				return null;
			}

		} else {
			return null;
		}
	}

}
