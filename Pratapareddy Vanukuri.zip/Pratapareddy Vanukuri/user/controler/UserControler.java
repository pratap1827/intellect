package user.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import user.UserResponse;
import user.bean.UserDetails;
import user.service.IUserService;

@RestController
public class UserControler {
	@Autowired
	private IUserService userService;

	@RequestMapping(value = "/api/createuser", method = RequestMethod.POST)
	public UserResponse createUser(UserDetails userBean) {
		UserDetails userData = userService.createUser(userBean);
		UserResponse response = new UserResponse();
		if (userData != null && userData.getId() != null) {
			response.setUserId(userData.getId());
			response.setMessage("User addtion is done successfully");
		} else {
			response.setError("Please provide valid data for create");
		}
		return response;
	}

	@RequestMapping(value = "/api/updateuser", method = RequestMethod.PUT)
	public UserResponse updateUser(UserDetails userBean) {
		UserDetails userData = userService.updateUser(userBean);
		UserResponse response = new UserResponse();
		if (userData != null && userData.getId() != null) {
			response.setUserId(userData.getId());
			response.setMessage("User updation is done successfully");
		} else {
			response.setError("Please provide valid data for update");
		}
		return response;
	}

	@RequestMapping(value = "/api/deleteuser", method = RequestMethod.GET)
	public UserResponse deleteUser(@RequestParam String id) {
		String userId = userService.deleteUser(id);
		UserResponse response = new UserResponse();
		if (userId != null) {
			response.setUserId(userId);
			response.setMessage("User deletion is done successfully");
		} else {
			response.setError("Please provide valid user id");
		}
		return response;
	}
}
